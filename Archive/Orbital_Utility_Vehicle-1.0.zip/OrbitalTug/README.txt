Extract to GamaData

Requires 
Firespitter DLL @ http://snjo.github.io/ or http://forum.kerbalspaceprogram.com/index.php?/topic/22583


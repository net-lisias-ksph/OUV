Extract to GamaData

Requires 
Firespitter DLL @ http://snjo.github.io/ or http://forum.kerbalspaceprogram.com/index.php?/topic/22583
ModuleManager @ http://forum.kerbalspaceprogram.com/index.php?/topic/50533-105-module-manager-2618-january-17th-with-even-more-sha-and-less-bug/


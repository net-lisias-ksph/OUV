# OrbitalTug
Continuation of Orbital Utility Vehicle by nli2work

Extract to your KSP folder. (changed mod file structure to GameData\OrbitalTug)

Requires 
ModuleManager @ http://forum.kerbalspaceprogram.com/index.php?/topic/50533-105-module-manager-2618-january-17th-with-even-more-sha-and-less-bug/
